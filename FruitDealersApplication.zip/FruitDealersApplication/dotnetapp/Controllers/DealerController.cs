using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using dotnetapp.Models;

namespace dotnetapp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DealerController : ControllerBase
    {
        private readonly FruitDealerDbContext _context;

        public DealerController(FruitDealerDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Dealer>>> GetAllDealers()
        {
            var dealers = await _context.Dealers.ToListAsync();
            return Ok(dealers);
        }
[HttpGet("{dealerID}")]
    public async Task<ActionResult<Dealer>> Get(int dealerID)
    {
        var dealer = await _context.Dealers.FindAsync(dealerID);

        if (dealer == null)
        {
            return NotFound();
        }

        return Ok(dealer);
    }
        [HttpPost]
        public async Task<ActionResult> AddDealer(Dealer dealer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Return detailed validation errors
            }
            await _context.Dealers.AddAsync(dealer);
            await _context.SaveChangesAsync();
            return Ok();
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDealer(int id)
        {
            if (id <= 0)
                return BadRequest("Not a valid Dealer id");

            var dealer = await _context.Dealers.FindAsync(id);
              _context.Dealers.Remove(dealer);
                await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
