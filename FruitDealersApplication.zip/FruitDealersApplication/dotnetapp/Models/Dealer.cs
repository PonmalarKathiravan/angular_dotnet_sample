using System;
using System.Collections.Generic;

namespace dotnetapp.Models;
public class Dealer
{
    public int DealerID { get; set; }
    public string DealerName { get; set; }
    public string Location { get; set; }
    public string ContactNumber { get; set; }
}
