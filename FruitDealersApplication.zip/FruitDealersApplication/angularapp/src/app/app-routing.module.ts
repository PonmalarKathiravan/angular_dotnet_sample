import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListComponent } from "./fruits/list/list.component";
import { DetailsComponent } from './fruits/details/details.component';
import { CreateComponent } from './fruits/create/create.component';
import { RouterTestingModule } from '@angular/router/testing';

const routes: Routes = [

  {path: 'fruits/list', component:ListComponent },
  {path: 'fruits/:fruitID/details', component:DetailsComponent},
  {path: 'fruits/create', component:CreateComponent},
  {path:'', redirectTo: 'fruits/list', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes),RouterTestingModule.withRoutes([])],
  exports: [RouterModule]
})
export class AppRoutingModule { }
