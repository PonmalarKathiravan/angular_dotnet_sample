export interface Dealer {
    dealerID:number;
    dealerName:string;
    location:string;
    contactNumber:string;
}
