import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Dealer } from '../dealer';
import { DealersService } from '../dealers.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  dealerID!: number;
  dealer: Dealer | undefined; // Initialize Dealer as undefined

  constructor(
    public dealersService: DealersService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.dealerID = this.route.snapshot.params['dealerID'];
    this.dealersService.getDealer(this.dealerID).subscribe(
      (data: Dealer) => {
        this.dealer = data;
      },
      (error) => {
        console.error('Error loading Dealer details:', error);
      }
    );
  }

  // Define the onBackToDealersList() method
  onBackToDealersList() {
    // Implement the logic to navigate back to the Dealers list page
    this.router.navigateByUrl('dealers/list');
  }
}
