import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { of } from 'rxjs';

import { DetailsComponent } from './details.component';
import { DealersService } from '../dealers.service';
import { Dealer } from '../dealer';

describe('DetailsComponent', () => {
  let component: DetailsComponent;
  let fixture: ComponentFixture<DetailsComponent>;
  let dealersService: jasmine.SpyObj<DealersService>;
  let router: jasmine.SpyObj<Router>;
  const dealerData: Dealer = {
    dealerID: 1,
    dealerName: 'Test Dealer',
    location: 'Test Location',
    contactNumber: '1234567890',
  };

  beforeEach(() => {
    const dealersServiceSpy = jasmine.createSpyObj('DealersService', ['getDealer']);
    const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);

    TestBed.configureTestingModule({
      declarations: [DetailsComponent],
      providers: [
        { provide: ActivatedRoute, useValue: { snapshot: { params: { dealerID: 1 } } } },
        { provide: DealersService, useValue: dealersServiceSpy },
        { provide: Router, useValue: routerSpy },
      ],
    });

    fixture = TestBed.createComponent(DetailsComponent);
    component = fixture.componentInstance;
    dealersService = TestBed.inject(DealersService) as jasmine.SpyObj<DealersService>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;

    dealersService.getDealer.and.returnValue(of(dealerData));

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load dealer details', () => {
    expect(dealersService.getDealer).toHaveBeenCalledWith(1);
    expect(component.dealer).toEqual(dealerData);

    // Test if dealer details are displayed in the HTML
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('h4').textContent).toContain(dealerData.dealerName);
    expect(compiled.querySelector('li:nth-child(1)').textContent).toContain(`Id: ${dealerData.dealerID}`);
    expect(compiled.querySelector('li:nth-child(2)').textContent).toContain(`Dealer Name: ${dealerData.dealerName}`);
    expect(compiled.querySelector('li:nth-child(3)').textContent).toContain(`Location: ${dealerData.location}`);
    expect(compiled.querySelector('li:nth-child(4)').textContent).toContain(`Contact Number: ${dealerData.contactNumber}`);
  });

  it('should navigate back to Dealers list', () => {
    component.onBackToDealersList();
    expect(router.navigateByUrl).toHaveBeenCalledWith('dealers/list');
  });
});
