import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { of } from 'rxjs';

import { CreateComponent } from './create.component';
import { DealersService } from '../dealers.service';
import { Dealer } from '../dealer'; // Import the Dealer interface

describe('CreateComponent', () => {
  let component: CreateComponent;
  let fixture: ComponentFixture<CreateComponent>;
  let dealersService: jasmine.SpyObj<DealersService>;
  let router: jasmine.SpyObj<Router>;

  beforeEach(() => {
    const dealersServiceSpy = jasmine.createSpyObj('DealersService', ['createDealer']);
    const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);

    TestBed.configureTestingModule({
      declarations: [CreateComponent],
      imports: [ReactiveFormsModule],
      providers: [
        { provide: ActivatedRoute, useValue: {} },
        { provide: DealersService, useValue: dealersServiceSpy },
        { provide: Router, useValue: routerSpy },
      ],
    });

    fixture = TestBed.createComponent(CreateComponent);
    component = fixture.componentInstance;
    dealersService = TestBed.inject(DealersService) as jasmine.SpyObj<DealersService>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize the form', () => {
    expect(component.createForm).toBeDefined();
  });

  it('should submit the form and call createDealer', () => {
    const formData = component.createForm;
    const dealerData = {
      dealerName: 'Test Dealer Name',
      location: 'Test Location',
      contactNumber: 'Test Contact Number',
    };

    formData.setValue(dealerData);

    // Trigger change detection to update form validity
    fixture.detectChanges();

    expect(formData.valid).toBeTruthy();

    // Create a Dealer object with valid data
    const newDealer: Dealer = {
      dealerID: 0, // Provide a valid dealerID
      ...dealerData, // Copy other properties from dealerData
    };

    dealersService.createDealer.and.returnValue(of(newDealer));
    component.onSubmit(formData);

    expect(dealersService.createDealer).toHaveBeenCalledWith(newDealer);
    expect(router.navigateByUrl).toHaveBeenCalledWith('dealers/list');
  });

  it('should render the form fields', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('h3').textContent).toContain('Create Dealer');

    expect(compiled.querySelector('form')).toBeTruthy();

    expect(compiled.querySelector('label[for="dealerName"]').textContent).toContain('Dealer Name');
    expect(compiled.querySelector('input[id="dealerName"][formControlName="dealerName"]')).toBeTruthy();

    expect(compiled.querySelector('label[for="location"]').textContent).toContain('Location');
    expect(compiled.querySelector('input[id="location"][formControlName="location"]')).toBeTruthy();

    expect(compiled.querySelector('label[for="contactNumber"]').textContent).toContain('Contact Number');
    expect(compiled.querySelector('input[id="contactNumber"][formControlName="contactNumber"]')).toBeTruthy();

    expect(compiled.querySelector('button[type="submit"]').textContent).toContain('Create');
  });
});
