import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { DealersService } from "../dealers.service";
import { Dealer } from '../dealer';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  createForm;

  constructor(
    public dealersService: DealersService,
    private route: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder
  ) {
    this.createForm = this.formBuilder.group({
      dealerName: ['', Validators.required],
      location: ['', Validators.required],
      contactNumber: ['']
    });
  }

   ngOnInit(): void {
  //   //this.positionsService.getPositions().subscribe((data: Position[]) => {
  //   //  this.positions = data;
  //  // });
   }

  onSubmit(formData: FormGroup) {

    const DealerData = formData.value;
  // Get the selected positionId from the form value
  //const selectedPositionId = DealerData.DealerID;

  // Create a Dealer object with the selected positionId
  const newDealer: Dealer = {
    dealerID: 0,
    dealerName: DealerData.dealerName,
    location: DealerData.location,
    contactNumber: DealerData.contactNumber
  };

  this.dealersService.createDealer(newDealer).subscribe(res => {
    this.router.navigateByUrl('dealers/list');
  });
  }
}