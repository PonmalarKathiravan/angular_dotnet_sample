import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DealersRoutingModule } from './dealers-routing.module';
import { DealersListComponent } from './list/list.component';
import { CreateComponent } from './create/create.component';
import { DetailsComponent } from './details/details.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    DealersListComponent,
    CreateComponent,
    DetailsComponent
  ],
  imports: [
    CommonModule,
    DealersRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class DealersModule { }
