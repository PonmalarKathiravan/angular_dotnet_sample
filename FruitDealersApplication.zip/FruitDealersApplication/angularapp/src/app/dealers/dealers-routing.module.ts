import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DealersListComponent } from './list/list.component';
import { CreateComponent } from './create/create.component';
import { DetailsComponent } from './details/details.component';


const routes: Routes = [
  { path: 'dealers', redirectTo: 'dealers/list', pathMatch: 'full' },
  { path: 'dealers/list', component: DealersListComponent },
  { path: 'dealers/:dealerID/details', component: DetailsComponent },
  { path: 'dealers/create', component: CreateComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DealersRoutingModule { }
