import { TestBed, inject, waitForAsync } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { DealersService } from './dealers.service';
import { Dealer } from './dealer';
import { of } from 'rxjs';

describe('DealersService', () => {
  let service: DealersService;
  let httpMock: HttpTestingController;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [DealersService],
    });

    service = TestBed.inject(DealersService);
    httpMock = TestBed.inject(HttpTestingController);
  }));

  fit('DealersService_should_be_created', () => {
    expect(service).toBeTruthy();
  });

  fit('DealersService_should_get_dealers', () => {
    const mockDealers: Dealer[] = [{ dealerID: 1, dealerName: 'Dealer A',location: 'A Location',contactNumber:'9876543210' }, { dealerID: 2, dealerName: 'Dealer B',location: 'B Location',contactNumber:'9876543010' }];

    service.getDealers().subscribe(dealers => {
      expect(dealers).toEqual(mockDealers);
    });

    const req = httpMock.expectOne(`${service['apiURL']}/Dealer`);
    expect(req.request.method).toBe('GET');
    req.flush(mockDealers);
  });

  fit('DealersService_should_get_dealer', () => {
    const mockDealer: Dealer = { dealerID: 1, dealerName: 'Dealer A',location: 'A Location',contactNumber:'9876543210' };

    service.getDealer(1).subscribe(dealer => {
      expect(dealer).toEqual(mockDealer);
    });

    const req = httpMock.expectOne(`${service['apiURL']}/Dealer/1`);
    expect(req.request.method).toBe('GET');
    req.flush(mockDealer);
  });

  fit('DealersService_should_create_dealer', () => {
    const mockDealer: Dealer = { dealerID: 1, dealerName: 'Dealer A',location: 'A Location',contactNumber:'9876543210' };

    service.createDealer(mockDealer).subscribe(response => {
      expect(response).toEqual(mockDealer);
    });

    const req = httpMock.expectOne(`${service['apiURL']}/Dealer/`);
    expect(req.request.method).toBe('POST');
    req.flush(mockDealer);
  });

  fit('DealersService_should_delete_dealer', () => {
    const dealerID = 1;

    service.deleteDealer(dealerID).subscribe(response => {
      expect(response).toBeTruthy();
    });

    const req = httpMock.expectOne(`${service['apiURL']}/Dealer/1`);
    expect(req.request.method).toBe('DELETE');
    req.flush({});
  });

  afterEach(() => {
    httpMock.verify();
  });
});
