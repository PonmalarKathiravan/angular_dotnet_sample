import { Component, OnInit } from '@angular/core';
import { Dealer } from "../dealer";
import { DealersService } from '../dealers.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class DealersListComponent implements OnInit{
  dealers: Dealer[] = [];

  constructor(public dealersService: DealersService) { }

  ngOnInit(): void {
    //throw new Error('Method not implemented.');
    this.dealersService.getDealers().subscribe((data: Dealer[]) => {
      this.dealers = data;
       // Log shirtNo values to the console
       this.dealers.forEach(dealer => {
        console.log('Dealer Name:', dealer.dealerName);
        console.log('Location', dealer.location);
        console.log('ContactNumber:', dealer.contactNumber);
      });
    });
  }
  deleteDealer(id: number ) {
    this.dealersService.deleteDealer(id).subscribe(res => {
      this.dealers = this.dealers.filter(item => item.dealerID !== id);
    });
  }

}
