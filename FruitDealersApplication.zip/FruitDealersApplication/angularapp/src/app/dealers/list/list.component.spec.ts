import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DealersListComponent } from './list.component';
import { DealersService } from '../dealers.service';
import { of } from 'rxjs';
import { Dealer } from '../dealer';
import { RouterTestingModule } from '@angular/router/testing'; // Import RouterTestingModule

describe('DealersListComponent', () => {
  let component: DealersListComponent;
  let fixture: ComponentFixture<DealersListComponent>;
  let dealersService: jasmine.SpyObj<DealersService>;
  const dealerData: Dealer[] = [
    {
      dealerID: 1,
      dealerName: 'Test Dealer 1',
      location: 'Test Location 1',
      contactNumber: '1234567890',
    },
    {
      dealerID: 2,
      dealerName: 'Test Dealer 2',
      location: 'Test Location 2',
      contactNumber: '9876543210',
    },
  ];

  beforeEach(() => {
    const dealersServiceSpy = jasmine.createSpyObj('DealersService', ['getDealers', 'deleteDealer']);

    TestBed.configureTestingModule({
      declarations: [DealersListComponent],
      imports: [RouterTestingModule], // Add RouterTestingModule
      providers: [{ provide: DealersService, useValue: dealersServiceSpy }],
    });

    fixture = TestBed.createComponent(DealersListComponent);
    component = fixture.componentInstance;
    dealersService = TestBed.inject(DealersService) as jasmine.SpyObj<DealersService>;

    dealersService.getDealers.and.returnValue(of(dealerData));

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load dealers list', () => {
    expect(dealersService.getDealers).toHaveBeenCalled();
    expect(component.dealers).toEqual(dealerData);

    // Test if dealer details are displayed in the HTML
    const compiled = fixture.nativeElement;
    expect(compiled.querySelectorAll('tr').length).toEqual(dealerData.length + 1); // Add 1 for the table header row
  });

  it('should delete a dealer', () => {
    const dealerIdToDelete = dealerData[0].dealerID;

    // Create a response that matches the expected type of the deleteDealer method
    const deleteResponse: Dealer = {
      dealerID: dealerIdToDelete,
      dealerName: 'Deleted Dealer',
      location: 'Deleted Location',
      contactNumber: 'Deleted Contact Number',
    };

    dealersService.deleteDealer.and.returnValue(of(deleteResponse));

    component.deleteDealer(dealerIdToDelete);

    expect(dealersService.deleteDealer).toHaveBeenCalledWith(dealerIdToDelete);
    expect(component.dealers.length).toEqual(dealerData.length - 1);
  });

});
