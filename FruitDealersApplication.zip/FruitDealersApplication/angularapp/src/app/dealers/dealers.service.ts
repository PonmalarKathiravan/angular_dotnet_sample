import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { Dealer } from "./dealer"

@Injectable({
  providedIn: 'root'
})
export class DealersService {

  private apiURL = "http://localhost:5131/api";
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private httpClient: HttpClient) { }

  getDealers(): Observable<Dealer[]> {
    return this.httpClient.get<Dealer[]>(this.apiURL + '/Dealer')
      .pipe(
        catchError(this.errorHandler.bind(this))
      );
  }

  getDealer(dealerID: number): Observable<Dealer> {
    console.log("ID"+dealerID);
    return this.httpClient.get<Dealer>(this.apiURL + '/Dealer/' + dealerID)
      .pipe(
        catchError(this.errorHandler.bind(this))
      );
  }

  createDealer(dealer: Dealer): Observable<Dealer> {

    // Create the Dealer object with the expected structure
    const newDealer = {
      dealerID: dealer.dealerID,
      dealerName: dealer.dealerName,
      location: dealer.location,
      contactNumber: dealer.contactNumber
    };

    // Log the Dealer object before sending the request
    console.log("Creating Dealer:", newDealer);

    return this.httpClient
      .post<Dealer>(`${this.apiURL}/Dealer/`, newDealer, this.httpOptions)
      .pipe(catchError(this.errorHandler.bind(this)));
  }

  deleteDealer(dealerID: number): Observable<Dealer> {
    return this.httpClient.delete<Dealer>(this.apiURL + '/Dealer/' + dealerID, this.httpOptions)
      .pipe(
        catchError(this.errorHandler.bind(this))
      );
  }
  errorHandler(error: HttpErrorResponse): Observable<never> {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}\nError Response: ${JSON.stringify(error.error)}`;
    }
    console.error(errorMessage); // Log the error
    return throwError(errorMessage);
  }
}
