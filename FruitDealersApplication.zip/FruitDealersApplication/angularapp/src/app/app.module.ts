import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { FruitsModule } from './fruits/fruits.module';
import { ListComponent } from './fruits/list/list.component';
import { DealersModule } from './dealers/dealers.module';
import { DealersListComponent } from './dealers/list/list.component';

@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    FruitsModule,
    DealersModule,
    RouterModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: 'fruits', component: ListComponent },
      {path:'dealers',component:DealersListComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
