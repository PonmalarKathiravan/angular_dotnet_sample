import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { of } from 'rxjs';

import { CreateComponent } from './create.component';
import { FruitsService } from '../fruits.service';
import { Fruit } from '../fruit';

describe('CreateComponent', () => {
  let component: CreateComponent;
  let fixture: ComponentFixture<CreateComponent>;
  let fruitsService: jasmine.SpyObj<FruitsService>;
  let router: jasmine.SpyObj<Router>;

  beforeEach(() => {
    const FruitsServiceSpy = jasmine.createSpyObj('FruitsService', ['createFruit']);
    const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);

    TestBed.configureTestingModule({
      declarations: [CreateComponent],
      imports: [ReactiveFormsModule],
      providers: [
        { provide: ActivatedRoute, useValue: {} },
        { provide: FruitsService, useValue: FruitsServiceSpy },
        { provide: Router, useValue: routerSpy },
      ],
    });

    fixture = TestBed.createComponent(CreateComponent);
    component = fixture.componentInstance;
    fruitsService = TestBed.inject(FruitsService) as jasmine.SpyObj<FruitsService>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize the form', () => {
    expect(component.createForm).toBeDefined();
  });

  it('should submit the form and call createFruit', () => {
    const formData = component.createForm;
const fruitData = {
  FruitName: 'Test Fruit Name',
  Description: 'Test description',
  Color: 'Test Color',
  Price: '100' // Change to a string
};

formData.setValue(fruitData);
    // Trigger change detection to update form validity
    fixture.detectChanges();

    expect(formData.valid).toBeTruthy();

    // Create a Fruit object with valid data
    const newFruit: Fruit = {
        fruitID: 0,
    fruitName: 'Test Fruit Name',
    description: 'Test description',
    color: 'Test Color',
    price: '100'
      };
    fruitsService.createFruit.and.returnValue(of(newFruit));
    component.onSubmit(formData);

    expect(fruitsService.createFruit).toHaveBeenCalledWith(newFruit);
    expect(router.navigateByUrl).toHaveBeenCalledWith('fruits/list');
  });

  it('should render the form fields', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('h3').textContent).toContain('Create Fruit');

    expect(compiled.querySelector('form')).toBeTruthy();

    expect(compiled.querySelector('label[for="FruitName"]').textContent).toContain('Fruit Name');
    expect(compiled.querySelector('input[id="FruitName"][formControlName="FruitName"]')).toBeTruthy();

    expect(compiled.querySelector('label[for="Description"]').textContent).toContain('Description');
    expect(compiled.querySelector('input[id="Description"][formControlName="Description"]')).toBeTruthy();

    expect(compiled.querySelector('label[for="Price"]').textContent).toContain('Price');
    expect(compiled.querySelector('input[id="Price"][formControlName="Price"]')).toBeTruthy();

    expect(compiled.querySelector('label[for="Color"]').textContent).toContain('Color');
    expect(compiled.querySelector('input[id="Color"][formControlName="Color"]')).toBeTruthy();

    expect(compiled.querySelector('button[type="submit"]').textContent).toContain('Create');
  });
});
