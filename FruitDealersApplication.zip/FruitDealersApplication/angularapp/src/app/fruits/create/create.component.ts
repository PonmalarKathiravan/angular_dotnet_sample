import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { FruitsService } from "../fruits.service";
import { Fruit } from '../fruit';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  createForm;

  constructor(
    public fruitsService: FruitsService,
    private route: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder
  ) {
    this.createForm = this.formBuilder.group({
      FruitName: ['', Validators.required],
      Description: ['', Validators.required],
      Color: [''],
      Price: ['']
    });
  }

   ngOnInit(): void {
  //   //this.positionsService.getPositions().subscribe((data: Position[]) => {
  //   //  this.positions = data;
  //  // });
   }

  onSubmit(formData: FormGroup) {

    const FruitData = formData.value;
  // Get the selected positionId from the form value
  //const selectedPositionId = FruitData.FruitID;

  // Create a Fruit object with the selected positionId
  const newFruit: Fruit = {
    fruitID: 0,
    fruitName: FruitData.FruitName,
    description: FruitData.Description,
    color: FruitData.Color,
    price: FruitData.Price
  };

  this.fruitsService.createFruit(newFruit).subscribe(res => {
    this.router.navigateByUrl('fruits/list');
  });
  }
}