import { Component, OnInit } from '@angular/core';
import { Fruit } from "../fruit";
import { FruitsService } from '../fruits.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit{
  fruits: Fruit[] = [];

  constructor(public fruitsService: FruitsService) { }

  ngOnInit(): void {
    //throw new Error('Method not implemented.');
    this.fruitsService.getFruits().subscribe((data: Fruit[]) => {
      this.fruits = data;
       // Log shirtNo values to the console
       this.fruits.forEach(Fruit => {
        console.log('Fruit Name:', Fruit.fruitName);
        console.log('Description', Fruit.description);
        console.log('Color:', Fruit.color);
        console.log('Price:', Fruit.price);
      });
    });
  }
  deleteFruit(id: number ) {
    this.fruitsService.deleteFruit(id).subscribe(res => {
      this.fruits = this.fruits.filter(item => item.fruitID !== id);
    });
  }

}
