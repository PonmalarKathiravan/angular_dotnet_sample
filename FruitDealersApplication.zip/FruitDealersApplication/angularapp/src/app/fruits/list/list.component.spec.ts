import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { ListComponent } from './list.component';
import { FruitsService } from '../fruits.service';
import { of, Observable } from 'rxjs';
import { Fruit } from '../fruit';

describe('ListComponent', () => {
  let component: ListComponent;
  let fixture: ComponentFixture<ListComponent>;
  let fruitsService: jasmine.SpyObj<FruitsService>;

  beforeEach(() => {
    const fruitsServiceSpy = jasmine.createSpyObj('FruitsService', ['getFruits', 'deleteFruit']);

    TestBed.configureTestingModule({
      declarations: [ListComponent],
      providers: [{ provide: FruitsService, useValue: fruitsServiceSpy }],
    }).compileComponents();

    fixture = TestBed.createComponent(ListComponent);
    component = fixture.componentInstance;
    fruitsService = TestBed.inject(FruitsService)as jasmine.SpyObj<FruitsService>;
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

    it('should delete a fruit', () => {
    const mockFruit: Fruit = { fruitID: 1, fruitName: 'Apple', description: 'A tasty fruit', color: 'Red', price: '1.00' };
    const deleteSpy = fruitsService.deleteFruit.and.returnValue(of(mockFruit));

    component.fruits = [mockFruit];

    component.deleteFruit(mockFruit.fruitID);

    expect(deleteSpy).toHaveBeenCalledWith(mockFruit.fruitID);
    expect(component.fruits.length).toBe(0);
  });
});
