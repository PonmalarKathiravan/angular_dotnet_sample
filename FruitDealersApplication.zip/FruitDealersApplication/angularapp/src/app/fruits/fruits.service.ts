import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { Fruit } from "./fruit"

@Injectable({
  providedIn: 'root'
})
export class FruitsService {

  private apiURL = "http://localhost:5131/api";
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private httpClient: HttpClient) { }

  getFruits(): Observable<Fruit[]> {
    return this.httpClient.get<Fruit[]>(this.apiURL + '/Fruit')
      .pipe(
        catchError(this.errorHandler.bind(this))
      );
  }

  getFruit(fruitID: number): Observable<Fruit> {
    console.log("ID"+fruitID);
    return this.httpClient.get<Fruit>(this.apiURL + '/Fruit/' + fruitID)
      .pipe(
        catchError(this.errorHandler.bind(this))
      );
  }

  createFruit(fruit: Fruit): Observable<Fruit> {

    // Create the Fruit object with the expected structure
    const newFruit = {
      fruitID: fruit.fruitID,
      fruitName: fruit.fruitName,
      description: fruit.description,
      color: fruit.color,
      price: fruit.price
    };

    // Log the Fruit object before sending the request
    console.log("Creating Fruit:", newFruit);

    return this.httpClient
      .post<Fruit>(`${this.apiURL}/Fruit/`, newFruit, this.httpOptions)
      .pipe(catchError(this.errorHandler.bind(this)));
  }

  updateFruit(fruitID: number, Fruit: Fruit): Observable<Fruit> {
    return this.httpClient.put<Fruit>(this.apiURL + '/Fruit/' + fruitID, JSON.stringify(Fruit), this.httpOptions)
      .pipe(
        catchError(this.errorHandler.bind(this))
      );
  }

  deleteFruit(fruitID: number): Observable<Fruit> {
    return this.httpClient.delete<Fruit>(this.apiURL + '/Fruit/' + fruitID, this.httpOptions)
      .pipe(
        catchError(this.errorHandler.bind(this))
      );
  }


  errorHandler(error: HttpErrorResponse): Observable<never> {
    let errorMessage = '';

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}\nError Response: ${JSON.stringify(error.error)}`;
    }
    console.error(errorMessage); // Log the error
    return throwError(errorMessage);
  }
}
