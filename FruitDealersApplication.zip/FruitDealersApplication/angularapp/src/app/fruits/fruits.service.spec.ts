import { TestBed, inject, waitForAsync } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FruitsService } from './fruits.service';
import { Fruit } from './fruit';
import { of } from 'rxjs';

describe('FruitsService', () => {
  let service: FruitsService;
  let httpMock: HttpTestingController;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [FruitsService],
    });

    service = TestBed.inject(FruitsService);
    httpMock = TestBed.inject(HttpTestingController);
  }));

  fit('FruitsService_should_be_created', () => {
    expect(service).toBeTruthy();
  });

  fit('FruitsService_should_get_fruits', () => {
    const mockFruits: Fruit[] = [
      { fruitID: 1, fruitName: 'Apple', description: 'A tasty fruit', color: 'Red', price: '1.00' },
      { fruitID: 2, fruitName: 'Banana', description: 'A yellow fruit', color: 'Yellow', price: '0.50' },
    ];

    service.getFruits().subscribe(fruits => {
      expect(fruits).toEqual(mockFruits);
    });

    const req = httpMock.expectOne(`${service['apiURL']}/Fruit`);
    expect(req.request.method).toBe('GET');
    req.flush(mockFruits);
  });

  fit('FruitsService_should_get_fruit', () => {
    const mockFruit: Fruit = {
      fruitID: 1,
      fruitName: 'Apple',
      description: 'A tasty fruit',
      color: 'Red',
      price: '1.00',
    };

    service.getFruit(1).subscribe(fruit => {
      expect(fruit).toEqual(mockFruit);
    });

    const req = httpMock.expectOne(`${service['apiURL']}/Fruit/1`);
    expect(req.request.method).toBe('GET');
    req.flush(mockFruit);
  });

  fit('FruitsService_should_create_fruit', () => {
    const mockFruit: Fruit = {
      fruitID: 1,
      fruitName: 'Apple',
      description: 'A tasty fruit',
      color: 'Red',
      price: '1.00',
    };

    service.createFruit(mockFruit).subscribe(response => {
      expect(response).toEqual(mockFruit);
    });

    const req = httpMock.expectOne(`${service['apiURL']}/Fruit/`);
    expect(req.request.method).toBe('POST');
    req.flush(mockFruit);
  });

  fit('FruitsService_should_update_fruit', () => {
    const fruitID = 1;
    const updatedFruit: Fruit = {
      fruitID: 1,
      fruitName: 'Updated Apple',
      description: 'Updated tasty fruit',
      color: 'Green',
      price: '1.50',
    };

    service.updateFruit(fruitID, updatedFruit).subscribe(response => {
      expect(response).toEqual(updatedFruit);
    });

    const req = httpMock.expectOne(`${service['apiURL']}/Fruit/1`);
    expect(req.request.method).toBe('PUT');
    req.flush(updatedFruit);
  });

  fit('FruitsService_should_delete_fruit', () => {
    const fruitID = 1;

    service.deleteFruit(fruitID).subscribe(response => {
      expect(response).toBeTruthy();
    });

    const req = httpMock.expectOne(`${service['apiURL']}/Fruit/1`);
    expect(req.request.method).toBe('DELETE');
    req.flush({});
  });

  afterEach(() => {
    httpMock.verify();
  });
});
