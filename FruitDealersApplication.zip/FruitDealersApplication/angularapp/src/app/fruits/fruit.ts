export interface Fruit {
    fruitID:number;
    fruitName: string;
    description:string;
    color:string;
    price:string;
}
