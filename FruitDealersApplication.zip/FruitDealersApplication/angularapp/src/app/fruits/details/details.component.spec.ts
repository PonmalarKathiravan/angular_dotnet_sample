import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { of, throwError } from 'rxjs';
import { DetailsComponent } from './details.component';
import { Fruit } from '../fruit';
import { FruitsService } from '../fruits.service';

describe('DetailsComponent', () => {
  let component: DetailsComponent;
  let fixture: ComponentFixture<DetailsComponent>;
  let mockFruitsService: jasmine.SpyObj<FruitsService>;
  let mockActivatedRoute: any;
  let mockRouter: any;

  beforeEach(() => {
    mockFruitsService = jasmine.createSpyObj('FruitsService', ['getFruit']);
    mockActivatedRoute = {
      snapshot: { params: { fruitID: 1 } },
    };
    mockRouter = jasmine.createSpyObj('Router', ['navigateByUrl']);

    TestBed.configureTestingModule({
      declarations: [DetailsComponent],
      providers: [
        { provide: FruitsService, useValue: mockFruitsService },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: Router, useValue: mockRouter },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(DetailsComponent);
    component = fixture.componentInstance;
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should render the fruit details correctly when `fruit` is defined', fakeAsync(() => {
    const mockFruit: Fruit = {
      fruitID: 1,
      fruitName: 'Apple',
      description: 'A tasty fruit',
      color: 'Red',
      price: '1.00',
    };

    mockFruitsService.getFruit.and.returnValue(of(mockFruit));

    component.ngOnInit();
    tick(); // Use tick to wait for the async operation to complete
    fixture.detectChanges();

    const element = fixture.nativeElement;

    expect(element.querySelector('h4').textContent).toContain('Apple');
    expect(element.querySelector('.list-group-item:nth-child(1)').textContent).toContain('Id: 1');
    expect(element.querySelector('.list-group-item:nth-child(2)').textContent).toContain('Fruit Name: Apple');
    expect(element.querySelector('.list-group-item:nth-child(3)').textContent).toContain('Description: A tasty fruit');
    expect(element.querySelector('.list-group-item:nth-child(4)').textContent).toContain('Color: Red');
    expect(element.querySelector('.list-group-item:nth-child(5)').textContent).toContain('Price: 1.00');
  }));

//   it('should not render the details when `fruit` is undefined', fakeAsync(() => {
//     component.fruit = undefined;

//     component.ngOnInit();
//     tick(); // Use tick to wait for the async operation to complete
//     fixture.detectChanges();

//     const element = fixture.nativeElement;

//     expect(element.querySelector('h4')).toBeNull();
//     expect(element.querySelector('.list-group-item')).toBeNull();
//   }));

  it('should retrieve fruit details and navigate to fruits list', fakeAsync(() => {
    const mockFruit: Fruit = {
      fruitID: 1,
      fruitName: 'Apple',
      description: 'A tasty fruit',
      color: 'Red',
      price: '1.00',
    };

    mockFruitsService.getFruit.and.returnValue(of(mockFruit));

    component.ngOnInit();
    tick(); // Use tick to wait for the async operation to complete
    fixture.detectChanges();

    expect(component.fruit).toEqual(mockFruit);
  }));

});
