import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Fruit } from '../fruit';
import { FruitsService } from '../fruits.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit, OnDestroy {
  fruitID!: number;
  fruit: Fruit | undefined;
  private subscription: Subscription;

  constructor(
    public fruitsService: FruitsService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.subscription = new Subscription();
  }

  ngOnInit(): void {
    this.fruitID = this.route.snapshot.params['fruitID'];
    this.subscription.add(
      this.fruitsService.getFruit(this.fruitID).subscribe(
        (data: Fruit) => {
          this.fruit = data;
        },
        (error) => {
          console.error('Error loading Fruit details:', error);
        }
      )
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  onBackToFruitsList() {
    this.router.navigateByUrl('Fruits/list');
  }
}
